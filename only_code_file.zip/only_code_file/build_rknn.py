# build_rknn.py（在服务器上跑）
from rknn.api import RKNN

ONNX_MODEL = "best.onnx"       # rockchip 魔改版导出的（9 输出）
RKNN_MODEL = "best_v2.rknn"    # 🔥 换个名字，避免和旧的搞混
DATASET = "dataset.txt"

rknn = RKNN(verbose=True)

rknn.config(
    mean_values=[[0, 0, 0]],
    std_values=[[255, 255, 255]],
    target_platform="rk3588",
)

ret = rknn.load_onnx(model=ONNX_MODEL)
assert ret == 0, "load_onnx failed"

ret = rknn.build(do_quantization=True, dataset=DATASET)
assert ret == 0, "build failed"

ret = rknn.export_rknn(RKNN_MODEL)    # 🔥 关键：这一步才会保存文件
assert ret == 0, "export failed"

print(f"✅ {RKNN_MODEL} 生成成功")
rknn.release()
