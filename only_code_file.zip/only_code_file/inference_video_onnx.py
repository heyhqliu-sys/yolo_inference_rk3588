import cv2
import numpy as np
import onnxruntime as ort

# ====================== 配置 ======================
ONNX_MODEL_PATH = "best.onnx"
IMG_SIZE = 1280
CONF_THRES = 0.5
IOU_THRES = 0.7
CLASSES = ["drone"]

VIDEO_PATH = "/ssd/project/haiquanliu/yolo_capture/yolov8_train/runs/drone_yolov8n/weights/video_1775725910761.mp4"
SAVE_VIDEO_PATH = "result_video.mp4"
# ====================================================


def letterbox(img, new_shape=(1280, 1280)):
    shape = img.shape[:2]
    r = min(new_shape[0] / shape[0], new_shape[1] / shape[1])
    new_unpad = (int(round(shape[1] * r)), int(round(shape[0] * r)))
    dw, dh = new_shape[1] - new_unpad[0], new_shape[0] - new_unpad[1]
    dw /= 2
    dh /= 2

    img = cv2.resize(img, new_unpad, interpolation=cv2.INTER_LINEAR)
    top, bottom = int(round(dh - 0.1)), int(round(dh + 0.1))
    left, right = int(round(dw - 0.1)), int(round(dw + 0.1))
    img = cv2.copyMakeBorder(img, top, bottom, left, right, cv2.BORDER_CONSTANT, value=(114, 114, 114))
    return img, r, dw, dh


def xywh2xyxy(xywh):
    x, y, w, h = xywh[:, 0], xywh[:, 1], xywh[:, 2], xywh[:, 3]
    x1 = x - w / 2
    y1 = y - h / 2
    x2 = x + w / 2
    y2 = y + h / 2
    return np.stack([x1, y1, x2, y2], axis=1)


def postprocess(output, conf_thres=0.25, iou_thres=0.45):
    output = output[0].transpose(1, 0)
    boxes_xywh = output[:, :4]
    scores = output[:, 4]
    mask = scores > conf_thres
    boxes = boxes_xywh[mask]
    scores = scores[mask]
    if len(boxes) == 0:
        return [], []
    boxes = xywh2xyxy(boxes)
    indices = cv2.dnn.NMSBoxes(boxes.tolist(), scores.tolist(), conf_thres, iou_thres)
    return boxes[indices], scores[indices]


def scale_boxes(boxes, r, dw, dh):
    boxes[:, [0, 2]] -= dw
    boxes[:, [1, 3]] -= dh
    boxes[:, :4] /= r
    return boxes.astype(int)


def infer_video(video_path, save_path="result_video.mp4"):
    cap = cv2.VideoCapture(video_path)
    fps = int(cap.get(cv2.CAP_PROP_FPS))
    width = int(cap.get(cv2.CAP_PROP_FRAME_WIDTH))
    height = int(cap.get(cv2.CAP_PROP_FRAME_HEIGHT))
    
    fourcc = cv2.VideoWriter_fourcc(*'mp4v')
    out = cv2.VideoWriter(save_path, fourcc, fps, (width, height))

    # ====================== 🔥 这里启用 CUDA ======================
    session = ort.InferenceSession(ONNX_MODEL_PATH, providers=['CUDAExecutionProvider', 'CPUExecutionProvider'])
    # ==============================================================

    input_name = session.get_inputs()[0].name
    output_name = session.get_outputs()[0].name

    print("✅ 使用 CUDA GPU 推理！")

    while True:
        ret, frame = cap.read()
        if not ret:
            break

        img_pre, r, dw, dh = letterbox(frame, (IMG_SIZE, IMG_SIZE))
        blob = img_pre.astype(np.float32) / 255.0
        blob = blob.transpose(2, 0, 1)
        blob = np.expand_dims(blob, axis=0)

        output = session.run([output_name], {input_name: blob})[0]
        boxes, scores = postprocess(output, CONF_THRES, IOU_THRES)

        if len(boxes):
            boxes = scale_boxes(boxes, r, dw, dh)

        for box, score in zip(boxes, scores):
            x1, y1, x2, y2 = box
            cv2.rectangle(frame, (x1, y1), (x2, y2), (0, 255, 0), 2)
            cv2.putText(frame, f"drone {score:.2f}", (x1, y1 - 10), cv2.FONT_HERSHEY_SIMPLEX, 1, (0, 255, 0), 2)

        out.write(frame)

    cap.release()
    out.release()
    print("✅ 视频处理完成")


if __name__ == "__main__":
    infer_video(VIDEO_PATH, SAVE_VIDEO_PATH)