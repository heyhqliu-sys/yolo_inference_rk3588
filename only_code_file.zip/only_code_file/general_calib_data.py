# gendata.py
import os, cv2, numpy as np

SRC_DIR = "./quantize_dataset"      # 原始校准图
DST_DIR = "./calib_npy"
IMG_SIZE = 1280
os.makedirs(DST_DIR, exist_ok=True)

def letterbox(img, new_shape=(1280, 1280)):
    shape = img.shape[:2]
    r = min(new_shape[0] / shape[0], new_shape[1] / shape[1])
    new_unpad = (int(round(shape[1] * r)), int(round(shape[0] * r)))
    dw = (new_shape[1] - new_unpad[0]) / 2
    dh = (new_shape[0] - new_unpad[1]) / 2
    img = cv2.resize(img, new_unpad, interpolation=cv2.INTER_LINEAR)
    top, bottom = int(round(dh - 0.1)), int(round(dh + 0.1))
    left, right = int(round(dw - 0.1)), int(round(dw + 0.1))
    return cv2.copyMakeBorder(img, top, bottom, left, right,
                              cv2.BORDER_CONSTANT, value=(114, 114, 114))

lines = []
for name in sorted(os.listdir(SRC_DIR)):
    if not name.lower().endswith((".jpg", ".jpeg", ".png", ".bmp")):
        continue
    img = cv2.imread(os.path.join(SRC_DIR, name))       # BGR
    if img is None:
        continue
    img = letterbox(img)                                # letterbox → 1280×1280
    blob = img.astype(np.float32)                       # 🔥 不除 255
    blob = blob.transpose(2, 0, 1)[None]                # (1, 3, 1280, 1280)
    out = os.path.join(DST_DIR, name.rsplit(".", 1)[0] + ".npy")
    np.save(out, blob)
    lines.append(os.path.abspath(out))

with open("dataset.txt", "w") as f:
    f.write("\n".join(lines))
print(f"✅ 生成 {len(lines)} 个 npy（未除 255）")