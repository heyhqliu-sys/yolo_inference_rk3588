from ultralytics import YOLO

model = YOLO("best.pt")  # 你的 pt 文件
model.export(
    format="onnx",
    opset=12,          # 🔥 关键：指定 opset 版本
    simplify=True,     # 简化模型
    dynamic=False,     # RKNN 不支持动态 shape
    imgsz=1280,
)