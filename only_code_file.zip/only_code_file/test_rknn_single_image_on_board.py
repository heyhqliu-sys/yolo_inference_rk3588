# test_rknn_board.py
import cv2
import numpy as np
import time
from rknnlite.api import RKNNLite

RKNN_MODEL = "best_v2.rknn"
VIDEO_PATH = "video_1775725910761.mp4"        # 🔥 改成你的视频路径
OUTPUT_PATH = "result_board_video.mp4"
IMG_SIZE = 1280
CONF_THRES = 0.25
IOU_THRES = 0.45
CLASSES = ["drone"]


def letterbox(img, new_shape=(1280, 1280)):
    shape = img.shape[:2]
    r = min(new_shape[0] / shape[0], new_shape[1] / shape[1])
    new_unpad = (int(round(shape[1] * r)), int(round(shape[0] * r)))
    dw = (new_shape[1] - new_unpad[0]) / 2
    dh = (new_shape[0] - new_unpad[1]) / 2
    img = cv2.resize(img, new_unpad, interpolation=cv2.INTER_LINEAR)
    top, bottom = int(round(dh - 0.1)), int(round(dh + 0.1))
    left, right = int(round(dw - 0.1)), int(round(dw + 0.1))
    img = cv2.copyMakeBorder(img, top, bottom, left, right,
                             cv2.BORDER_CONSTANT, value=(114, 114, 114))
    return img, r, dw, dh


def dfl(position):
    n, c, h, w = position.shape
    mc = c // 4
    y = position.reshape(n, 4, mc, h, w)
    y = np.exp(y - y.max(axis=2, keepdims=True))
    y = y / y.sum(axis=2, keepdims=True)
    acc = np.arange(mc, dtype=np.float32).reshape(1, 1, mc, 1, 1)
    return (y * acc).sum(axis=2)


def box_process(position, stride):
    grid_h, grid_w = position.shape[2:4]
    col, row = np.meshgrid(np.arange(grid_w), np.arange(grid_h))
    grid = np.stack((col, row), axis=0).reshape(1, 2, grid_h, grid_w).astype(np.float32)
    position = dfl(position)
    box_xy = (grid + 0.5 - position[:, 0:2]) * stride
    box_xy2 = (grid + 0.5 + position[:, 2:4]) * stride
    return np.concatenate((box_xy, box_xy2), axis=1)


def post_process(outputs, conf_thres=0.25, iou_thres=0.45):
    boxes, classes_conf = [], []
    pair = len(outputs) // 3
    strides = [IMG_SIZE // outputs[pair * i].shape[2] for i in range(3)]

    for i in range(3):
        boxes.append(box_process(outputs[pair * i], strides[i]))
        classes_conf.append(outputs[pair * i + 1])

    def flatten(x):
        ch = x.shape[1]
        return x.transpose(0, 2, 3, 1).reshape(-1, ch)

    boxes = np.concatenate([flatten(b) for b in boxes])
    classes_conf = np.concatenate([flatten(c) for c in classes_conf])

    classes = np.argmax(classes_conf, axis=-1)
    max_conf = np.max(classes_conf, axis=-1)
    keep = max_conf >= conf_thres
    boxes, scores, classes = boxes[keep], max_conf[keep], classes[keep]
    if len(boxes) == 0:
        return np.array([]), np.array([]), np.array([])

    nms_boxes = boxes.copy()
    nms_boxes[:, 2] -= nms_boxes[:, 0]
    nms_boxes[:, 3] -= nms_boxes[:, 1]
    idx = cv2.dnn.NMSBoxes(nms_boxes.tolist(), scores.tolist(), conf_thres, iou_thres)
    if len(idx) == 0:
        return np.array([]), np.array([]), np.array([])
    idx = np.array(idx).flatten()
    return boxes[idx], scores[idx], classes[idx]


def scale_boxes(boxes, r, dw, dh):
    boxes[:, [0, 2]] -= dw
    boxes[:, [1, 3]] -= dh
    boxes[:, :4] /= r
    return boxes.astype(int)


# ==================== 初始化（板端 NPU）====================
rknn = RKNNLite()
ret = rknn.load_rknn(RKNN_MODEL)
assert ret == 0, "load_rknn failed"

ret = rknn.init_runtime(core_mask=RKNNLite.NPU_CORE_0_1_2)
assert ret == 0, "init_runtime failed"
print("✅ RKNN 初始化完成（NPU 三核）")

# ==================== 视频处理 ====================
cap = cv2.VideoCapture(VIDEO_PATH)
assert cap.isOpened(), f"❌ 无法打开视频: {VIDEO_PATH}"

fps = cap.get(cv2.CAP_PROP_FPS)
w = int(cap.get(cv2.CAP_PROP_FRAME_WIDTH))
h = int(cap.get(cv2.CAP_PROP_FRAME_HEIGHT))
total = int(cap.get(cv2.CAP_PROP_FRAME_COUNT))
print(f"视频: {w}x{h}, {fps:.1f}fps, {total} 帧")

fourcc = cv2.VideoWriter_fourcc(*"mp4v")
writer = cv2.VideoWriter(OUTPUT_PATH, fourcc, fps, (w, h))

frame_idx = 0
total_infer = 0
total_post = 0

while True:
    ret, frame = cap.read()
    if not ret:
        break
    frame_idx += 1

    # 预处理
    img_pre, r, dw, dh = letterbox(frame, (IMG_SIZE, IMG_SIZE))
    rknn_input = np.expand_dims(img_pre, 0)    # (1,1280,1280,3) uint8 BGR

    # NPU 推理
    t0 = time.time()
    outputs = rknn.inference(inputs=[rknn_input], data_format=["nhwc"])
    t1 = time.time()

    # 后处理（CPU）
    boxes, scores, classes = post_process(outputs, CONF_THRES, IOU_THRES)
    if len(boxes):
        boxes = scale_boxes(boxes, r, dw, dh)
    t2 = time.time()

    total_infer += (t1 - t0)
    total_post += (t2 - t1)

    # 画框
    for box, score, cls in zip(boxes, scores, classes):
        x1, y1, x2, y2 = box
        cv2.rectangle(frame, (x1, y1), (x2, y2), (0, 255, 0), 2)
        cv2.putText(frame, f"{CLASSES[cls]} {score:.2f}", (x1, max(y1 - 10, 0)),
                    cv2.FONT_HERSHEY_SIMPLEX, 0.8, (0, 255, 0), 2)

    writer.write(frame)

    if frame_idx % 50 == 0:
        avg_infer = (total_infer / frame_idx) * 1000
        avg_post = (total_post / frame_idx) * 1000
        det = len(boxes) if len(boxes) else 0
        print(f"  [{frame_idx}/{total}] 检出 {det} | "
              f"NPU推理 {(t1-t0)*1000:.1f}ms | "
              f"后处理 {(t2-t1)*1000:.1f}ms | "
              f"均值 {avg_infer:.1f}+{avg_post:.1f}ms")

cap.release()
writer.release()
rknn.release()

avg_infer_ms = (total_infer / frame_idx) * 1000
avg_post_ms = (total_post / frame_idx) * 1000
avg_total = avg_infer_ms + avg_post_ms
print(f"\n✅ 完成! 共 {frame_idx} 帧")
print(f"   NPU 推理: {avg_infer_ms:.1f}ms/帧")
print(f"   后处理:   {avg_post_ms:.1f}ms/帧")
print(f"   总计:     {avg_total:.1f}ms/帧 ({1000/avg_total:.1f} FPS)")
