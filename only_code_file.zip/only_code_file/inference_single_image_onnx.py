import cv2
import numpy as np
import onnxruntime as ort

# ====================== 配置（你的模型）======================
ONNX_MODEL_PATH = "best1.onnx"  # 你的ONNX路径
IMG_SIZE = 1280
CONF_THRES = 0.5
IOU_THRES = 0.7
CLASSES = ["drone"]
# =============================================================


def letterbox(img, new_shape=(1280, 1280)):
    """YOLOv8 预处理：等比例缩放 + 灰色填充"""
    shape = img.shape[:2]
    r = min(new_shape[0] / shape[0], new_shape[1] / shape[1])
    new_unpad = (int(round(shape[1] * r)), int(round(shape[0] * r)))
    dw, dh = new_shape[1] - new_unpad[0], new_shape[0] - new_unpad[1]
    dw /= 2
    dh /= 2

    img = cv2.resize(img, new_unpad, interpolation=cv2.INTER_LINEAR)
    top, bottom = int(round(dh - 0.1)), int(round(dh + 0.1))
    left, right = int(round(dw - 0.1)), int(round(dw + 0.1))
    img = cv2.copyMakeBorder(img, top, bottom, left, right, cv2.BORDER_CONSTANT, value=(114, 114, 114))
    return img, r, dw, dh


def xywh2xyxy(xywh):
    x, y, w, h = xywh[:, 0], xywh[:, 1], xywh[:, 2], xywh[:, 3]
    x1 = x - w / 2
    y1 = y - h / 2
    x2 = x + w / 2
    y2 = y + h / 2
    return np.stack([x1, y1, x2, y2], axis=1)


def postprocess(output, conf_thres=0.25, iou_thres=0.45):
    """后处理：解析 [1,5,33600]"""
    output = output[0].transpose(1, 0)  # [33600, 5]

    boxes_xywh = output[:, :4]
    scores = output[:, 4]

    # 置信度过滤
    mask = scores > conf_thres
    boxes = boxes_xywh[mask]
    scores = scores[mask]

    if len(boxes) == 0:
        return [], []

    boxes = xywh2xyxy(boxes)

    # NMS
    indices = cv2.dnn.NMSBoxes(boxes.tolist(), scores.tolist(), conf_thres, iou_thres)
    return boxes[indices], scores[indices]


def scale_boxes(boxes, r, dw, dh):
    """还原到原图坐标"""
    boxes[:, [0, 2]] -= dw
    boxes[:, [1, 3]] -= dh
    boxes[:, :4] /= r
    return boxes.astype(int)


# ====================== 推理主函数 ======================
def infer_image(image_path):
    # 1. 读图
    img = cv2.imread(image_path)
    h, w = img.shape[:2]

    # 2. LetterBox 预处理
    img_pre, r, dw, dh = letterbox(img, (IMG_SIZE, IMG_SIZE))

    # 3. 归一化 + 通道转换
    blob = img_pre.astype(np.float32) / 255.0
    blob = blob.transpose(2, 0, 1)  # HWC -> CHW
    blob = np.expand_dims(blob, axis=0)  # [1,3,1280,1280]

    # 4. ONNX 推理
    session = ort.InferenceSession(ONNX_MODEL_PATH, providers=["CPUExecutionProvider"])
    input_name = session.get_inputs()[0].name
    output_name = session.get_outputs()[0].name
    output = session.run([output_name], {input_name: blob})[0]

    # 5. 后处理
    boxes, scores = postprocess(output, CONF_THRES, IOU_THRES)

    # 6. 坐标还原
    if len(boxes):
        boxes = scale_boxes(boxes, r, dw, dh)

    # 7. 画框
    for box, score in zip(boxes, scores):
        x1, y1, x2, y2 = box
        cv2.rectangle(img, (x1, y1), (x2, y2), (0, 255, 0), 2)
        cv2.putText(img, f"drone {score:.2f}", (x1, y1 - 10), cv2.FONT_HERSHEY_SIMPLEX, 1, (0, 255, 0), 2)

    cv2.imwrite("result.jpg", img)
    print("✅ 检测完成，保存为 result.jpg")
    return boxes, scores


if __name__ == "__main__":
    infer_image("/ssd/project/haiquanliu/yolo_capture/yolov8_train/frames/frame_000099.jpg")  # 换成你的图片路径